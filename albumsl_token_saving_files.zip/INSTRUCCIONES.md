# AlbumSL token-saving files

Copiar estos archivos en la raíz del repo `AlbumSL`:

```txt
AGENTS.md
docs/AI_ROUTER.md
.gga-rules.md
.gga
```

Archivos auxiliares:

```txt
README_SNIPPET.md
AGENTS_DOCS_PATCH.md
```

Después de copiar:

```powershell
git status --short
npm.cmd run format:check
git diff --check
```

Si querés validar más:

```powershell
npm.cmd run typecheck
```

Antes de commit importante:

```powershell
npm.cmd run validate
```
